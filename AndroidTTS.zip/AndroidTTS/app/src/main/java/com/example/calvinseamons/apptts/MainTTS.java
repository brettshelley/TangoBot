package com.example.calvinseamons.apptts;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;


public class MainTTS extends AppCompatActivity {

    static TTS lettuce = new TTS();
    private static TextToSpeech mTTS;
    private Button mButtonSpeak;
    private Button button;
    private TextView txvResult;
    private String[] test = new String[10];
    public static String start = "";
    public static String phrase = "";
    static Boolean send = false;
    public static ImageView activate;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_tts);
        mButtonSpeak = findViewById(R.id.button_speak);
        button = findViewById(R.id.button);
        activate = findViewById(R.id.btnSpeak);
        txvResult = (TextView) findViewById(R.id.txvResult);

        mTTS = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int status) {
                    if (status == TextToSpeech.SUCCESS) {
                        int result = mTTS.setLanguage(Locale.US);

                        if (result == TextToSpeech.LANG_MISSING_DATA
                                || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                            Log.e("TTS", "Language not supported");
                        } else {
                            mButtonSpeak.setEnabled(true);
                            new SendMessage().execute();
                        }
                    } else {
                        Log.e("TTS", "Initialization failed");
                    }
                }
            });

        final EditText editText = (EditText) findViewById(R.id.edit_text);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        mButtonSpeak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lettuce.start(mTTS, "Beep Beep Lettuce");

            }
        });

    }



    public static void speak(String m){
        lettuce.start(mTTS, m);
    }


    @Override
    protected void onDestroy() {
        if (mTTS != null) {
            mTTS.stop();
            mTTS.shutdown();
        }

        super.onDestroy();
    }

    //--------------Speech to text---------------//
    public void getSpeechInput() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, 10);
        } else {
            Toast.makeText(this, "Your Device Don't Support Speech Input", Toast.LENGTH_SHORT).show();
        }
    }

    public void startSpeech(){
        getSpeechInput();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case 10:
                if (resultCode == RESULT_OK && data != null) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    txvResult.setText(result.get(0));
                    //System.out.println(result.get(0));
                    start = result.get(0);
                    System.out.println("--------"+start+"--------");

                    if(!start.contains("start")){
                        getSpeechInput();
                        //new SendMessage().execute();

                        //Here we will send to the python to used as a command
                    }
                    else{
                        send = true;
                        System.out.println("it worked!!!");
                        //new SendMessage().execute();

                        //We will have code here that starts the python shit
                    }

                    }

                    break;
                }
        }

    }




