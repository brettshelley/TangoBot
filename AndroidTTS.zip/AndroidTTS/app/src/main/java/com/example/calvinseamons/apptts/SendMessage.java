package com.example.calvinseamons.apptts;
import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class SendMessage extends AsyncTask<Void,Void,Void>{
    private Exception exception;
    Socket socket;
    DataOutputStream out;
    BufferedReader in;
    String m;

    @Override
    protected  Void doInBackground(Void... params){
        try{
            try{
                System.out.println("Trying Connection");

                    while (true) {
                        socket = new Socket("10.200.1.119", 5000);
                        out = new DataOutputStream(socket.getOutputStream());
                        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                        while (!in.ready()) {}

                        m = in.readLine();

                        if (m.equals("listen")) {
                            MainTTS.activate.callOnClick();

                            while (!MainTTS.send) {}

                            if (MainTTS.send) {
                                System.out.println(MainTTS.start);
                                out.writeBytes(MainTTS.start);
                                MainTTS.start = "";
                                System.out.println("SENT MESSAGE");
                                MainTTS.send = false;
                            }
                        }
                        else {
                            MainTTS.speak(m);
                        }



                        System.out.println("------------>" + m);

                        m = "";
                        socket.close();
                    }
                    //MainTTS.runCommands();

                    //System.out.println("Connection worked");
            } catch (IOException e){
                e.printStackTrace();
            }
        } catch (Exception e){
            this.exception = e;
            return null;
        }
    return null;

    }

}
